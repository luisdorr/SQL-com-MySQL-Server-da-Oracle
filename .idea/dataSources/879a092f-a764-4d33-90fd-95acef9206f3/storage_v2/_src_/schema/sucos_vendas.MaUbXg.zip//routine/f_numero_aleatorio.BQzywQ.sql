create
    definer = root@localhost function f_numero_aleatorio(min int, max int) returns int deterministic
BEGIN
	DECLARE vRetorno INT;
    SELECT FLOOR((RAND() * (max - min + 1)) + min) INTO vRetorno;
RETURN vRetorno;
END;

