create
    definer = root@localhost procedure local_date_hour()
BEGIN
declare ts datetime default localtimestamp();
select ts;
END;

