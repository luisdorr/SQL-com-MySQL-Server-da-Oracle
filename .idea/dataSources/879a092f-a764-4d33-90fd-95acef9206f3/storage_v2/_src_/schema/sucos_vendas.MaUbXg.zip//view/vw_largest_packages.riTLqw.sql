create definer = luis@`%` view vw_largest_packages as
select `sucos_vendas`.`tabela_de_produtos`.`EMBALAGEM`           AS `EMBALAGEM`,
       max(`sucos_vendas`.`tabela_de_produtos`.`PRECO_DE_LISTA`) AS `BIGGEST_PRICE`
from `sucos_vendas`.`tabela_de_produtos`
group by `sucos_vendas`.`tabela_de_produtos`.`EMBALAGEM`;

