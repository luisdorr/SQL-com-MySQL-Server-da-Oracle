create
    definer = root@localhost function f_cliente_aleatorio() returns varchar(11) deterministic
BEGIN
	DECLARE vRetorno VARCHAR(11);
    DECLARE num_max_tabela INT;
    DECLARE numero_aleatorio_inteiro INT;
    
    SELECT COUNT(*) INTO num_max_tabela FROM tabela_de_clientes;
    SET numero_aleatorio_inteiro = f_numero_aleatorio(1, num_max_tabela) - 1;
    
    SELECT CPF INTO vRetorno FROM tabela_de_clientes
    LIMIT numero_aleatorio_inteiro, 1;
RETURN vRetorno;
END;

