create
    definer = root@localhost procedure do_nothing()
BEGIN

END;

