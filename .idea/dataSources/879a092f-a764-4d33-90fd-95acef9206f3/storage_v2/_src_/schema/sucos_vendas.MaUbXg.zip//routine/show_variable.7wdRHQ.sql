create
    definer = luis@`%` procedure show_variable()
BEGIN
declare text char(12) default 'Hello World!';
SELECT text;
END;

