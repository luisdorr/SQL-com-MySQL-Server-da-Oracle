create
    definer = root@localhost procedure new_procedure()
BEGIN
SELECT 'HELLOOOOO WOOOORLD!!!';
END;

