create
    definer = luis@`%` procedure inclui_novo_produto_parametro(IN vCodigo varchar(50), IN vNome varchar(50),
                                                               IN vSabor varchar(50), IN vTamanho varchar(50),
                                                               IN vEmbalagem varchar(50), IN vPreco decimal(10, 2))
BEGIN
DECLARE mensagem VARCHAR(30);
DECLARE EXIT HANDLER for 1062
BEGIN
	SET mensagem = 'Problema de chave primaria';
    SELECT mensagem;
END;

INSERT INTO tabela_de_produtos
(CODIGO_DO_PRODUTO,NOME_DO_PRODUTO,SABOR,TAMANHO,EMBALAGEM,PRECO_DE_LISTA)
     VALUES (vCodigo,
     vNome,
     vSabor,
     vTamanho,
     vEmbalagem,
     vPreco);
     SET mensagem = 'Produto incluido com sucesso !!!';
     SELECT mensagem;
END;

