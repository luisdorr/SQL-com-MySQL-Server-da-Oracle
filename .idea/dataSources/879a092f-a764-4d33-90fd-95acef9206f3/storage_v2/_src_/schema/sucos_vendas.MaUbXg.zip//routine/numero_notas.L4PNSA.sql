create
    definer = root@localhost function numero_notas(DATA date) returns int
BEGIN
	DECLARE NUMNOTAS INT;
    
	SELECT COUNT(*) INTO NUMNOTAS 
    FROM notas_fiscais 
    WHERE DATA_VENDA = DATA;
    
	RETURN NUMNOTAS;
END;

